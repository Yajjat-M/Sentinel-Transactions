import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { z } from "zod";

function parseResponse<T>(schema: z.ZodSchema<T>, data: unknown, label: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    console.error(`[Zod] ${label} validation failed:`, result.error.format());
    return data as T;
  }
  return result.data;
}

export function useIncidents() {
  return useQuery({
    queryKey: [api.incidents.list.path],
    queryFn: async () => {
      const res = await fetch(api.incidents.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch incidents");
      const data = await res.json();
      return parseResponse(api.incidents.list.responses[200], data, "incidents.list");
    },
    refetchInterval: 3000,
  });
}
