import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { z } from "zod";

function parseResponse<T>(schema: z.ZodSchema<T>, data: unknown, label: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    console.error(`[Zod] ${label} validation failed:`, result.error.format());
    return data as T;
  }
  return result.data;
}

export function useAgentLogs() {
  return useQuery({
    queryKey: [api.agent.logs.path],
    queryFn: async () => {
      const res = await fetch(api.agent.logs.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch agent logs");
      const data = await res.json();
      return parseResponse(api.agent.logs.responses[200], data, "agent.logs");
    },
    refetchInterval: 1000,
  });
}
