import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";

function parseResponse<T>(schema: z.ZodSchema<T>, data: unknown, label: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    console.error(`[Zod] ${label} validation failed:`, result.error.format());
    return data as T;
  }
  return result.data;
}

export function useMetricsHistory(metric?: string, hours: number = 1) {
  return useQuery({
    queryKey: [api.metrics.history.path, metric, hours],
    queryFn: async () => {
      // Manually construct query string since buildUrl is for path params usually
      const url = `${api.metrics.history.path}?hours=${hours}${metric ? `&metric=${metric}` : ''}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch metrics history");
      const data = await res.json();
      return parseResponse(api.metrics.history.responses[200], data, "metrics.history");
    },
    refetchInterval: 5000,
  });
}
