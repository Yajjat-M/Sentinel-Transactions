import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { z } from "zod";

function parseResponse<T>(schema: z.ZodSchema<T>, data: unknown, label: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    console.error(`[Zod] ${label} validation failed:`, result.error.format());
    return data as T;
  }
  return result.data;
}

export function useSimulationStatus() {
  return useQuery({
    queryKey: [api.simulation.status.path],
    queryFn: async () => {
      const res = await fetch(api.simulation.status.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch simulation status");
      const data = await res.json();
      return parseResponse(api.simulation.status.responses[200], data, "simulation.status");
    },
    refetchInterval: 1000,
  });
}

export function useSimulationControl() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (input: z.infer<typeof api.simulation.control.input>) => {
      const res = await fetch(api.simulation.control.path, {
        method: api.simulation.control.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(input),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to control simulation");
      const data = await res.json();
      return parseResponse(api.simulation.control.responses[200], data, "simulation.control");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.simulation.status.path] });
    },
  });
}
