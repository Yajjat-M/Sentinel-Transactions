import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { z } from "zod";

// Helper to handle Zod parsing with error logging
function parseResponse<T>(schema: z.ZodSchema<T>, data: unknown, label: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    console.error(`[Zod] ${label} validation failed:`, result.error.format());
    // For now, return data casted to T to prevent app crash, but log error
    return data as T; 
  }
  return result.data;
}

export function useDashboardStats() {
  return useQuery({
    queryKey: [api.dashboard.stats.path],
    queryFn: async () => {
      const res = await fetch(api.dashboard.stats.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch dashboard stats");
      const data = await res.json();
      return parseResponse(api.dashboard.stats.responses[200], data, "dashboard.stats");
    },
    refetchInterval: 1000, // Real-time polling
  });
}

export function useRecentTransactions() {
  return useQuery({
    queryKey: [api.dashboard.recentTransactions.path],
    queryFn: async () => {
      const res = await fetch(api.dashboard.recentTransactions.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch recent transactions");
      const data = await res.json();
      return parseResponse(api.dashboard.recentTransactions.responses[200], data, "dashboard.recentTransactions");
    },
    refetchInterval: 2000,
  });
}
