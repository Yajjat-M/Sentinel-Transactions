import { useAgentLogs } from "@/hooks/use-agent";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Brain, Eye, Zap, BookOpen } from "lucide-react";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";

const ModuleIcon = ({ module }: { module: string }) => {
  switch (module.toLowerCase()) {
    case 'observe': return <Eye className="h-3.5 w-3.5 text-blue-400" />;
    case 'reason': return <Brain className="h-3.5 w-3.5 text-purple-400" />;
    case 'decide': return <Zap className="h-3.5 w-3.5 text-orange-400" />;
    case 'act': return <Zap className="h-3.5 w-3.5 text-green-400" />; // Decide and act share icon for now
    case 'learn': return <BookOpen className="h-3.5 w-3.5 text-pink-400" />;
    default: return <Activity className="h-3.5 w-3.5 text-gray-400" />;
  }
};

const ModuleColor = (module: string) => {
  switch (module.toLowerCase()) {
    case 'observe': return "border-blue-500/30 bg-blue-500/5 text-blue-200";
    case 'reason': return "border-purple-500/30 bg-purple-500/5 text-purple-200";
    case 'decide': return "border-orange-500/30 bg-orange-500/5 text-orange-200";
    case 'act': return "border-green-500/30 bg-green-500/5 text-green-200";
    case 'learn': return "border-pink-500/30 bg-pink-500/5 text-pink-200";
    default: return "border-gray-500/30 bg-gray-500/5 text-gray-200";
  }
};

import { Activity } from "lucide-react";

export function AgentFeed() {
  const { data: logs, isLoading } = useAgentLogs();

  if (isLoading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-card rounded-xl border border-border/40 overflow-hidden shadow-sm">
      <div className="p-4 border-b border-border/40 flex items-center justify-between bg-muted/20">
        <div className="flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
          <h3 className="font-semibold text-sm">Agent Live Feed</h3>
        </div>
        <span className="text-xs text-muted-foreground font-mono">LIVE</span>
      </div>
      
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-3 relative">
          <div className="absolute left-[19px] top-2 bottom-2 w-[1px] bg-border/40 z-0" />
          
          <AnimatePresence initial={false}>
            {logs?.map((log) => (
              <motion.div
                key={log.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3 }}
                className="relative z-10 pl-2"
              >
                <div className={`
                  p-3 rounded-lg border text-xs font-mono
                  flex flex-col gap-1.5 shadow-sm backdrop-blur-sm
                  ${ModuleColor(log.module)}
                `}>
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className={`p-1 rounded-md bg-background/50 border border-white/5`}>
                        <ModuleIcon module={log.module} />
                      </div>
                      <span className="font-bold uppercase tracking-wider text-[10px] opacity-80">
                        {log.module}
                      </span>
                    </div>
                    <span className="text-[10px] opacity-50">
                      {format(new Date(log.timestamp), "HH:mm:ss.SSS")}
                    </span>
                  </div>
                  
                  <p className="leading-relaxed pl-8 opacity-90 font-sans">
                    {log.message}
                  </p>
                  
                  {log.details && (
                    <div className="ml-8 mt-1 p-2 rounded bg-background/30 border border-white/5 text-[10px] overflow-x-auto">
                      <pre>{JSON.stringify(log.details, null, 2)}</pre>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          
          {(!logs || logs.length === 0) && (
            <div className="text-center py-10 text-muted-foreground text-sm">
              Waiting for agent activity...
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
