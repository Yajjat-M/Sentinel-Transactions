import { useSimulationStatus, useSimulationControl } from "@/hooks/use-simulation";
import { Play, Pause, RotateCcw, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

export function SimulationControl() {
  const { data: status, isLoading } = useSimulationStatus();
  const { mutate: control, isPending } = useSimulationControl();
  const { toast } = useToast();

  const handleAction = (action: 'start' | 'stop' | 'reset' | 'seed') => {
    control({ action }, {
      onSuccess: (data) => {
        toast({
          title: "Simulation Updated",
          description: data.message,
        });
      }
    });
  };

  if (isLoading) return <div className="animate-pulse h-10 w-32 bg-muted rounded-md" />;

  const isRunning = status?.isRunning;

  return (
    <div className="flex items-center gap-4 bg-card/50 border border-border/40 rounded-xl p-2 pr-4 shadow-sm backdrop-blur-sm">
      <div className="flex items-center gap-2 pl-2 border-r border-border/40 pr-4">
        <Zap className={`h-4 w-4 ${isRunning ? "text-yellow-400 fill-yellow-400" : "text-muted-foreground"}`} />
        <div className="flex flex-col">
          <span className="text-[10px] uppercase font-bold text-muted-foreground tracking-wider">Status</span>
          <span className={`text-xs font-bold ${isRunning ? "text-primary" : "text-muted-foreground"}`}>
            {isRunning ? "RUNNING" : "STOPPED"}
          </span>
        </div>
      </div>
      
      <div className="flex items-center gap-2">
        {isRunning ? (
          <Button 
            variant="outline" 
            size="sm" 
            className="h-8 px-3 border-destructive/30 hover:bg-destructive/10 hover:text-destructive hover:border-destructive/50"
            onClick={() => handleAction('stop')}
            disabled={isPending}
          >
            <Pause className="h-3.5 w-3.5 mr-1.5" />
            Pause
          </Button>
        ) : (
          <Button 
            variant="default" 
            size="sm" 
            className="h-8 px-3 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold shadow-md shadow-primary/20"
            onClick={() => handleAction('start')}
            disabled={isPending}
          >
            <Play className="h-3.5 w-3.5 mr-1.5 fill-current" />
            Start
          </Button>
        )}

        <Button 
          variant="ghost" 
          size="icon" 
          className="h-8 w-8 text-muted-foreground hover:text-foreground"
          onClick={() => handleAction('reset')}
          disabled={isPending}
          title="Reset Simulation"
        >
          <RotateCcw className="h-3.5 w-3.5" />
        </Button>
      </div>

      <div className="hidden md:flex items-center gap-2 text-xs text-muted-foreground ml-2">
        <Badge variant="secondary" className="font-mono text-[10px] h-5">
          {status?.speed?.toFixed(1) || 0} TPS
        </Badge>
        <span className="text-[10px]">{status?.processedCount?.toLocaleString()} processed</span>
      </div>
    </div>
  );
}
