import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Activity, 
  ShieldAlert, 
  BrainCircuit,
  Settings2
} from "lucide-react";
import { cn } from "@/lib/utils";

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Transactions", href: "/transactions", icon: Activity },
  { name: "Incidents", href: "/incidents", icon: ShieldAlert },
  { name: "Agent Logic", href: "/agent", icon: BrainCircuit },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="flex h-full w-64 flex-col bg-card border-r border-border/40">
      <div className="flex h-16 items-center px-6 border-b border-border/40">
        <BrainCircuit className="h-6 w-6 text-primary mr-2" />
        <span className="text-lg font-bold font-display tracking-tight text-foreground">
          FinAgent<span className="text-primary">.ai</span>
        </span>
      </div>
      
      <div className="flex-1 overflow-y-auto py-6 px-3">
        <nav className="space-y-1">
          {navigation.map((item) => {
            const isActive = location === item.href;
            return (
              <Link 
                key={item.name} 
                href={item.href}
                className={cn(
                  "group flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-all duration-200",
                  isActive 
                    ? "bg-primary/10 text-primary shadow-sm ring-1 ring-primary/20" 
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                )}
              >
                <item.icon
                  className={cn(
                    "mr-3 h-5 w-5 flex-shrink-0 transition-colors",
                    isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"
                  )}
                  aria-hidden="true"
                />
                {item.name}
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="p-4 border-t border-border/40">
        <div className="bg-muted/50 rounded-lg p-3">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
              <span className="text-xs font-bold text-primary">JD</span>
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">Jane Doe</p>
              <p className="text-xs text-muted-foreground">Lead Engineer</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
