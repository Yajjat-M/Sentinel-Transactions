import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Transactions from "@/pages/Transactions";
import Incidents from "@/pages/Incidents";
import AgentLogic from "@/pages/AgentLogic";
import { Sidebar } from "@/components/Sidebar";
import { SimulationControl } from "@/components/SimulationControl";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/transactions" component={Transactions} />
      <Route path="/incidents" component={Incidents} />
      <Route path="/agent" component={AgentLogic} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="flex h-screen w-screen overflow-hidden bg-background text-foreground font-sans">
          {/* Sidebar Navigation */}
          <aside className="shrink-0 z-20">
            <Sidebar />
          </aside>

          {/* Main Content Area */}
          <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
            
            {/* Top Header / Toolbar */}
            <header className="h-16 border-b border-border/40 flex items-center justify-between px-6 bg-card/50 backdrop-blur-sm shrink-0 z-10">
              <div>
                <h2 className="text-sm font-medium text-muted-foreground">
                  Operational Command Center
                </h2>
              </div>
              <SimulationControl />
            </header>

            {/* Scrollable Page Content */}
            <div className="flex-1 overflow-auto bg-background/50 relative">
              {/* Background decorative elements */}
              <div className="absolute top-0 left-0 w-full h-96 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none" />
              
              <Router />
            </div>
          </main>
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
