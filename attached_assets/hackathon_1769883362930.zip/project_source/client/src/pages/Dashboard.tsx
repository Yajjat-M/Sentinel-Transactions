import { useDashboardStats } from "@/hooks/use-dashboard";
import { StatsCard } from "@/components/StatsCard";
import { AgentFeed } from "@/components/AgentFeed";
import { 
  Activity, 
  AlertTriangle, 
  ShieldAlert, 
  TrendingUp, 
  DollarSign 
} from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useMetricsHistory } from "@/hooks/use-metrics";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useDashboardStats();
  const { data: metrics } = useMetricsHistory(undefined, 1); // Get 1 hour of history

  // Format metrics for chart
  const chartData = metrics?.map(m => ({
    time: format(new Date(m.timestamp), "HH:mm:ss"),
    value: m.value,
    name: m.name
  })).filter(m => m.name === 'transaction_volume') || [];

  return (
    <div className="p-6 h-[calc(100vh-4rem)] overflow-hidden flex flex-col gap-6">
      {/* Top Stats Row */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 shrink-0">
        {statsLoading ? (
          Array(4).fill(0).map((_, i) => <Skeleton key={i} className="h-32 rounded-xl" />)
        ) : (
          <>
            <StatsCard
              title="Total Volume"
              value={`$${(stats?.totalVolume || 0).toLocaleString()}`}
              icon={DollarSign}
              trend="up"
              trendValue="+12.5%"
              description="from last hour"
            />
            <StatsCard
              title="Failure Rate"
              value={`${(stats?.failureRate || 0).toFixed(2)}%`}
              icon={Activity}
              trend={stats?.failureRate && stats.failureRate > 5 ? "down" : "up"}
              trendValue={stats?.failureRate && stats.failureRate > 5 ? "+2.1%" : "-0.5%"}
              description="monitor active"
            />
            <StatsCard
              title="Fraud Risk"
              value={`${(stats?.fraudRate || 0).toFixed(2)}%`}
              icon={ShieldAlert}
              trend="neutral"
              description="stable detected"
            />
            <StatsCard
              title="Active Incidents"
              value={stats?.activeIncidents || 0}
              icon={AlertTriangle}
              trend={stats?.activeIncidents && stats.activeIncidents > 0 ? "down" : "up"}
              className={stats?.activeIncidents && stats.activeIncidents > 0 ? "border-destructive/50 bg-destructive/5" : ""}
            />
          </>
        )}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 min-h-0">
        
        {/* Left Column: Charts & Tables */}
        <div className="lg:col-span-2 flex flex-col gap-6 min-h-0">
          
          {/* Main Chart */}
          <Card className="flex-1 min-h-[300px] border-border/40 bg-card shadow-sm flex flex-col">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-medium flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                Transaction Volume Real-time
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 min-h-0 pb-4">
              <div className="h-full w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                    <XAxis 
                      dataKey="time" 
                      stroke="hsl(var(--muted-foreground))" 
                      fontSize={12} 
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis 
                      stroke="hsl(var(--muted-foreground))" 
                      fontSize={12} 
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={(value) => `$${value}`}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))', 
                        borderColor: 'hsl(var(--border))',
                        borderRadius: '8px',
                        boxShadow: '0 4px 12px rgba(0,0,0,0.1)' 
                      }}
                      itemStyle={{ color: 'hsl(var(--foreground))' }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="value" 
                      stroke="hsl(var(--primary))" 
                      strokeWidth={2}
                      fillOpacity={1} 
                      fill="url(#colorValue)" 
                      isAnimationActive={false}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Bottom Table: Risky Banks */}
          <Card className="h-64 border-border/40 bg-card shadow-sm overflow-hidden flex flex-col shrink-0">
            <CardHeader className="pb-2 bg-muted/20 border-b border-border/40">
              <CardTitle className="text-sm font-medium">Top High Risk Banks</CardTitle>
            </CardHeader>
            <div className="overflow-auto flex-1 p-0">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-muted-foreground bg-muted/30 uppercase">
                  <tr>
                    <th className="px-6 py-3">Bank Name</th>
                    <th className="px-6 py-3">Status</th>
                    <th className="px-6 py-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {stats?.topRiskyBanks.map((bank, i) => (
                    <tr key={i} className="hover:bg-muted/10 transition-colors">
                      <td className="px-6 py-3 font-medium">{bank}</td>
                      <td className="px-6 py-3">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-red-500/10 text-red-500 border border-red-500/20">
                          High Failure Rate
                        </span>
                      </td>
                      <td className="px-6 py-3 text-right">
                        <button className="text-primary hover:underline text-xs">Investigate</button>
                      </td>
                    </tr>
                  ))}
                  {(!stats?.topRiskyBanks || stats.topRiskyBanks.length === 0) && (
                    <tr>
                      <td colSpan={3} className="px-6 py-8 text-center text-muted-foreground text-xs">
                        No risky banks detected currently.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </div>

        {/* Right Column: Agent Feed */}
        <div className="lg:col-span-1 h-full min-h-0">
          <AgentFeed />
        </div>
      </div>
    </div>
  );
}
