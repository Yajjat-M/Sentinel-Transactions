import { useRecentTransactions } from "@/hooks/use-dashboard";
import { format } from "date-fns";
import { 
  CheckCircle2, 
  XCircle, 
  AlertOctagon, 
  ShieldCheck, 
  ShieldAlert 
} from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Transactions() {
  const { data: transactions, isLoading } = useRecentTransactions();

  return (
    <div className="p-6 h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Transactions</h1>
          <p className="text-muted-foreground">Real-time monitoring of payment flows.</p>
        </div>
      </div>

      <Card className="flex-1 border-border/40 shadow-sm overflow-hidden flex flex-col">
        <CardHeader className="bg-muted/20 border-b border-border/40 py-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-medium">Recent Activity</CardTitle>
            <Badge variant="outline" className="font-mono text-xs">
              Live
            </Badge>
          </div>
        </CardHeader>
        
        <div className="flex-1 overflow-auto">
          {isLoading ? (
            <div className="p-8 text-center text-muted-foreground">Loading transactions...</div>
          ) : (
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-muted-foreground bg-muted/30 uppercase sticky top-0 z-10 backdrop-blur-sm">
                <tr>
                  <th className="px-6 py-3">Timestamp</th>
                  <th className="px-6 py-3">Transaction ID</th>
                  <th className="px-6 py-3">Bank</th>
                  <th className="px-6 py-3">Amount</th>
                  <th className="px-6 py-3">Status</th>
                  <th className="px-6 py-3">Fraud Score</th>
                  <th className="px-6 py-3 text-right">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/40">
                {transactions?.map((tx) => (
                  <tr key={tx.id} className="hover:bg-muted/10 transition-colors group">
                    <td className="px-6 py-3 font-mono text-xs text-muted-foreground">
                      {format(new Date(tx.timestamp), "HH:mm:ss")}
                    </td>
                    <td className="px-6 py-3 font-mono text-xs">
                      {tx.transactionId.slice(0, 8)}...
                    </td>
                    <td className="px-6 py-3">{tx.bank}</td>
                    <td className="px-6 py-3 font-medium">
                      {tx.currency} {tx.amount.toFixed(2)}
                    </td>
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        {tx.status === 'success' && <CheckCircle2 className="h-4 w-4 text-green-500" />}
                        {tx.status === 'failed' && <XCircle className="h-4 w-4 text-red-500" />}
                        {tx.status === 'halted' && <AlertOctagon className="h-4 w-4 text-orange-500" />}
                        <span className={`capitalize ${
                          tx.status === 'success' ? 'text-green-500' : 
                          tx.status === 'failed' ? 'text-red-500' : 'text-orange-500'
                        }`}>
                          {tx.status}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        {(tx.fraudProbability || 0) > 0.7 ? (
                          <ShieldAlert className="h-4 w-4 text-red-500" />
                        ) : (
                          <ShieldCheck className="h-4 w-4 text-green-500" />
                        )}
                        <span className={`font-mono ${(tx.fraudProbability || 0) > 0.7 ? 'text-red-500 font-bold' : 'text-muted-foreground'}`}>
                          {((tx.fraudProbability || 0) * 100).toFixed(1)}%
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-3 text-right">
                      <button className="text-muted-foreground hover:text-primary transition-colors">
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </Card>
    </div>
  );
}
