import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { Brain, ArrowRight, Zap, Eye, Database } from "lucide-react";

const LogicStep = ({ 
  icon: Icon, 
  title, 
  description, 
  colorClass 
}: { 
  icon: any, 
  title: string, 
  description: string, 
  colorClass: string 
}) => (
  <Card className={`border-border/40 relative overflow-hidden group hover:border-${colorClass.split('-')[1]}-500/50 transition-colors`}>
    <div className={`absolute top-0 left-0 w-1 h-full bg-${colorClass.split('-')[1]}-500 opacity-60`} />
    <CardHeader>
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-2 ${colorClass} bg-opacity-10`}>
        <Icon className={`h-6 w-6 text-${colorClass.split('-')[1]}-500`} />
      </div>
      <CardTitle className="text-lg">{title}</CardTitle>
      <CardDescription>{description}</CardDescription>
    </CardHeader>
  </Card>
);

export default function AgentLogic() {
  return (
    <div className="p-6 h-full overflow-y-auto">
      <div className="max-w-4xl mx-auto">
        <div className="mb-10 text-center">
          <h1 className="text-3xl font-bold font-display tracking-tight mb-2">Agent Logic Loop</h1>
          <p className="text-muted-foreground text-lg">
            Visualizing the O-R-D-A (Observe, Reason, Decide, Act) feedback loop.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
          
          <LogicStep 
            icon={Eye} 
            title="Observe" 
            description="Ingests real-time transaction stream and system health metrics." 
            colorClass="text-blue-500"
          />
          
          <div className="hidden md:flex justify-center">
            <ArrowRight className="text-muted-foreground/30 h-8 w-8 animate-pulse" />
          </div>

          <LogicStep 
            icon={Brain} 
            title="Reason" 
            description="Applies ML models to detect anomalies and fraud patterns." 
            colorClass="text-purple-500"
          />

          <div className="hidden md:flex justify-center">
            <ArrowRight className="text-muted-foreground/30 h-8 w-8 animate-pulse" />
          </div>

          <LogicStep 
            icon={Zap} 
            title="Decide" 
            description="Evaluates policy rules against reasoning output to form a decision." 
            colorClass="text-orange-500"
          />

          <div className="hidden md:flex justify-center">
            <ArrowRight className="text-muted-foreground/30 h-8 w-8 animate-pulse" />
          </div>

          <LogicStep 
            icon={Database} 
            title="Act" 
            description="Executes action (block, flag, allow) and updates system state." 
            colorClass="text-green-500"
          />
          
        </div>

        <div className="mt-12">
          <h2 className="text-xl font-bold mb-6">Current Policies</h2>
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="bg-muted/10 border-border/40">
              <CardHeader>
                <CardTitle className="text-base">High Velocity Check</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                IF transaction_count {'>'} 100 per minute per bank<br/>
                THEN flag incident type "retry_storm"<br/>
                AND activate circuit breaker
              </CardContent>
            </Card>
            
            <Card className="bg-muted/10 border-border/40">
              <CardHeader>
                <CardTitle className="text-base">Fraud Threshold</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                IF fraud_probability {'>'} 0.85<br/>
                THEN status = "halted"<br/>
                AND severity = "high"
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
