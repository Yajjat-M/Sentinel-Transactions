import { useIncidents } from "@/hooks/use-incidents";
import { format } from "date-fns";
import { 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  MoreHorizontal 
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export default function Incidents() {
  const { data: incidents, isLoading } = useIncidents();

  const getSeverityColor = (severity: string) => {
    switch(severity) {
      case 'critical': return 'bg-red-500/10 text-red-500 border-red-500/20';
      case 'high': return 'bg-orange-500/10 text-orange-500 border-orange-500/20';
      case 'medium': return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
      default: return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
    }
  };

  return (
    <div className="p-6 h-full overflow-y-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Incident Management</h1>
          <p className="text-muted-foreground">Active operational issues and resolution status.</p>
        </div>
        <Button>
          Create Incident
        </Button>
      </div>

      <div className="grid gap-4">
        {isLoading ? (
          <div>Loading incidents...</div>
        ) : incidents?.map((incident) => (
          <Card key={incident.id} className="border-border/40 hover:border-primary/50 transition-colors">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-4">
                  <div className={`p-3 rounded-xl ${
                    incident.status === 'resolved' 
                      ? 'bg-green-500/10 text-green-500' 
                      : 'bg-destructive/10 text-destructive'
                  }`}>
                    {incident.status === 'resolved' ? (
                      <CheckCircle className="h-6 w-6" />
                    ) : (
                      <AlertTriangle className="h-6 w-6" />
                    )}
                  </div>
                  
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <h3 className="font-semibold text-lg">{incident.type.replace('_', ' ').toUpperCase()}</h3>
                      <Badge variant="outline" className={getSeverityColor(incident.severity)}>
                        {incident.severity}
                      </Badge>
                      <Badge variant="secondary" className="capitalize">
                        {incident.status}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground mb-4 max-w-2xl">
                      {incident.description}
                    </p>
                    
                    <div className="flex items-center gap-6 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        Detected: {format(new Date(incident.detectedAt), "MMM d, HH:mm")}
                      </div>
                      {incident.resolvedAt && (
                        <div className="flex items-center gap-2 text-green-500">
                          <CheckCircle className="h-4 w-4" />
                          Resolved: {format(new Date(incident.resolvedAt), "MMM d, HH:mm")}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <Button variant="ghost" size="icon">
                  <MoreHorizontal className="h-5 w-5 text-muted-foreground" />
                </Button>
              </div>

              {incident.evidence && (
                <div className="mt-4 pt-4 border-t border-border/40">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Evidence</h4>
                  <pre className="bg-muted/30 p-3 rounded-lg text-xs font-mono overflow-x-auto text-foreground/80">
                    {JSON.stringify(incident.evidence, null, 2)}
                  </pre>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
        
        {(!incidents || incidents.length === 0) && (
          <div className="text-center py-12 bg-muted/10 rounded-xl border border-dashed border-border">
            <CheckCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium">All Systems Operational</h3>
            <p className="text-muted-foreground">No active incidents detected.</p>
          </div>
        )}
      </div>
    </div>
  );
}
