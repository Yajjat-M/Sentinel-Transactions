## Packages
recharts | For real-time charts and data visualization
framer-motion | For smooth animations and transitions
date-fns | For date formatting
clsx | For conditional class names (utility)
tailwind-merge | For merging tailwind classes (utility)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  mono: ["JetBrains Mono", "monospace"],
  display: ["Space Grotesk", "sans-serif"],
}
