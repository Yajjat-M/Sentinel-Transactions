import pandas as pd
import numpy as np
import os
from datetime import datetime

class DatasetLoader:
    def __init__(self, data_dir="attached_assets"):
        self.data_dir = data_dir
        self.fraud_data_path = None
        self.upi_data_path = None
        self.txn_data_path = None
        
        # Find files
        for f in os.listdir(data_dir):
            if "fraud_data" in f:
                self.fraud_data_path = os.path.join(data_dir, f)
            elif "upi_transactions" in f:
                self.upi_data_path = os.path.join(data_dir, f)
            elif "transaction_data" in f:
                self.txn_data_path = os.path.join(data_dir, f)

    def load_fraud_data(self):
        if not self.fraud_data_path:
            raise FileNotFoundError("Fraud dataset not found")
        df = pd.read_csv(self.fraud_data_path)
        return df

    def load_upi_data(self):
        if not self.upi_data_path:
            raise FileNotFoundError("UPI dataset not found")
        df = pd.read_csv(self.upi_data_path)
        return df

    def load_txn_data(self):
        if not self.txn_data_path:
            raise FileNotFoundError("Transaction dataset not found")
        df = pd.read_csv(self.txn_data_path)
        return df

    def get_unified_stream(self):
        """
        Merges and unifies datasets into a single event stream sorted by time.
        """
        # Load all
        fraud_df = self.load_fraud_data()
        upi_df = self.load_upi_data()
        txn_df = self.load_txn_data() # This has latency

        # --- Process Fraud Data ---
        # Columns: id, timestamp, amount, bank, status, error_code, fraud_score, attempt_count
        fraud_df['timestamp'] = pd.to_datetime(fraud_df['timestamp'])
        fraud_unified = fraud_df.rename(columns={
            'id': 'transaction_id',
            'bank': 'issuer_bank',
            'attempt_count': 'retry_count'
        })
        fraud_unified['source'] = 'fraud_dataset'
        
        # --- Process UPI Data ---
        # Columns: transaction id, timestamp, amount (INR), transaction_status, sender_bank
        upi_df['timestamp'] = pd.to_datetime(upi_df['timestamp'])
        upi_unified = upi_df.rename(columns={
            'transaction id': 'transaction_id',
            'amount (INR)': 'amount',
            'transaction_status': 'status',
            'sender_bank': 'issuer_bank'
        })
        upi_unified['status'] = upi_unified['status'].str.lower()
        upi_unified['source'] = 'upi_dataset'
        
        # --- Process Transaction Data (Latency source) ---
        # Columns: Transaction ID, Timestamp, Latency (ms), Transaction Status
        txn_df['timestamp'] = pd.to_datetime(txn_df['Timestamp'])
        txn_unified = txn_df.rename(columns={
            'Transaction ID': 'transaction_id',
            'Transaction Amount': 'amount',
            'Transaction Status': 'status',
            'Latency (ms)': 'latency_ms'
        })
        txn_unified['status'] = txn_unified['status'].str.lower()
        txn_unified['source'] = 'txn_dataset'

        # --- Merge / Concatenate ---
        # We want a single stream. Since IDs are different, we concat and fill missing.
        # Common columns: transaction_id, timestamp, amount, status, issuer_bank, latency_ms, retry_count, fraud_score
        
        common_cols = ['transaction_id', 'timestamp', 'amount', 'status', 'issuer_bank', 'latency_ms', 'retry_count', 'fraud_score', 'error_code']
        
        # Ensure columns exist
        for df in [fraud_unified, upi_unified, txn_unified]:
            for col in common_cols:
                if col not in df.columns:
                    df[col] = np.nan

        unified = pd.concat([
            fraud_unified[common_cols], 
            upi_unified[common_cols],
            txn_unified[common_cols]
        ], ignore_index=True)

        # Sort by timestamp
        unified = unified.sort_values('timestamp')
        
        # Fill missing values with simulation logic
        # If latency is missing, simulate based on status (failed might be higher or timeout)
        # If retry_count is missing, default to 1
        
        unified['retry_count'] = unified['retry_count'].fillna(1)
        
        # Simulate latency if missing
        # Normal dist around 200ms for success, higher for failure
        mask_latency_nan = unified['latency_ms'].isna()
        unified.loc[mask_latency_nan, 'latency_ms'] = np.random.normal(200, 50, mask_latency_nan.sum())
        # Make failed transactions have higher latency sometimes
        mask_failed = (unified['status'] == 'failed') & mask_latency_nan
        unified.loc[mask_failed, 'latency_ms'] += np.random.exponential(1000, mask_failed.sum())
        
        unified['latency_ms'] = unified['latency_ms'].clip(lower=10) # min 10ms

        # Normalize status
        unified['status'] = unified['status'].map({'success': 'SUCCESS', 'failed': 'FAILED', 'SUCCESS': 'SUCCESS', 'FAILED': 'FAILED'})
        
        return unified

if __name__ == "__main__":
    loader = DatasetLoader()
    df = loader.get_unified_stream()
    print(df.head())
    print(df.columns)
