import pandas as pd
import time

class StreamSimulator:
    def __init__(self, dataframe):
        self.dataframe = dataframe
        self.current_idx = 0
    
    def stream(self, batch_size=1, delay=0.1):
        """
        Yields transactions one by one or in batches.
        """
        total = len(self.dataframe)
        while self.current_idx < total:
            batch = self.dataframe.iloc[self.current_idx : self.current_idx + batch_size]
            self.current_idx += batch_size
            
            for _, row in batch.iterrows():
                yield row.to_dict()
                time.sleep(delay)
