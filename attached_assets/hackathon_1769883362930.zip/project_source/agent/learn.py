class LearningModule:
    def __init__(self):
        self.history = []

    def learn(self, action_log, outcome_metrics):
        """
        Evaluate action effectiveness.
        outcome_metrics: metrics observed AFTER the action.
        """
        action = action_log.get('action_taken')
        if action == 'monitor':
            return None # No learning from passive monitoring yet
        
        # Determine if action was successful
        # Simple heuristic: Did success rate improve?
        current_success_rate = outcome_metrics.get('global_success_rate', 0)
        
        # We need previous state to compare, but for now let's assume if rate is good (> 0.8) it was a success
        success = current_success_rate > 0.8
        
        feedback = {
            'action': action,
            'success': success,
            'cost': 0 # Placeholder
        }
        
        self.history.append({
            'action_log': action_log,
            'feedback': feedback
        })
        
        return feedback
