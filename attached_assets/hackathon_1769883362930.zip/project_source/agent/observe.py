import pandas as pd
import numpy as np

class PaymentObserver:
    def __init__(self, window_size=50):
        self.window_size = window_size
        self.history = []
        self.bank_stats = {}

    def observe(self, transaction):
        """
        Ingest a transaction and update internal state/metrics.
        """
        self.history.append(transaction)
        if len(self.history) > self.window_size * 10: # Keep a buffer but don't grow infinitely
            self.history = self.history[-self.window_size*2:]

        # Update bank specific stats
        bank = transaction.get('issuer_bank')
        status = transaction.get('status')
        
        if bank not in self.bank_stats:
            self.bank_stats[bank] = {'total': 0, 'failed': 0, 'latency_sum': 0}
        
        self.bank_stats[bank]['total'] += 1
        if status == 'FAILED':
            self.bank_stats[bank]['failed'] += 1
        
        self.bank_stats[bank]['latency_sum'] += transaction.get('latency_ms', 0)

    def get_metrics(self):
        """
        Calculate current metrics based on recent window.
        """
        recent = self.history[-self.window_size:] if self.history else []
        if not recent:
            return {}

        df = pd.DataFrame(recent)
        
        # Global Success Rate
        success_rate = (df['status'] == 'SUCCESS').mean()
        
        # Avg Latency
        avg_latency = df['latency_ms'].mean()

        # Bank Failure Rates
        bank_failure_rates = {}
        if 'issuer_bank' in df.columns:
            for bank, group in df.groupby('issuer_bank'):
                fail_rate = (group['status'] == 'FAILED').mean()
                bank_failure_rates[bank] = fail_rate

        return {
            'global_success_rate': success_rate,
            'global_avg_latency': avg_latency,
            'bank_failure_rates': bank_failure_rates,
            'recent_transaction_count': len(df)
        }
