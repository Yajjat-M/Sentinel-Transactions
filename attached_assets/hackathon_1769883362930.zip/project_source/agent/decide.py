import random

class DecisionEngine:
    def __init__(self):
        # Weights for learning
        self.weights = {
            'retry': 0.5,
            'reroute': 0.5,
            'suppress': 0.5,
            'alert': 0.5
        }

    def decide(self, hypotheses):
        """
        Select best action based on hypotheses.
        """
        decision = {
            'action': 'monitor',
            'reason': 'No critical issues detected',
            'parameters': {}
        }

        # Prioritize highest impact hypothesis
        critical_hypothesis = None
        max_conf = -1
        
        for h in hypotheses:
            if h['impact'] == 'high' and h['confidence'] > max_conf:
                max_conf = h['confidence']
                critical_hypothesis = h
        
        if not critical_hypothesis:
            # Check medium impact
             for h in hypotheses:
                if h['impact'] == 'medium' and h['confidence'] > max_conf:
                    max_conf = h['confidence']
                    critical_hypothesis = h

        if critical_hypothesis:
            h_type = critical_hypothesis['type']
            target = critical_hypothesis['target']
            
            if h_type == 'issuer_downtime':
                # Decision: Reroute or Suppress
                if self.weights['reroute'] > 0.4:
                    decision = {
                        'action': 'reroute',
                        'reason': f"High failure rate at {target}. Rerouting to backup.",
                        'parameters': {'target_bank': target, 'backup': 'GenericBackupBank'}
                    }
                else:
                     decision = {
                        'action': 'suppress',
                        'reason': f"High failure rate at {target}. Suppressing traffic.",
                        'parameters': {'target_bank': target}
                    }
            
            elif h_type == 'network_congestion':
                # Decision: Adjust Retry
                decision = {
                    'action': 'adjust_retry',
                    'reason': "Network congestion detected. Increasing retry backoff.",
                    'parameters': {'backoff_factor': 2.0}
                }
            
            elif h_type == 'fraud_attack':
                 decision = {
                    'action': 'block_transaction',
                    'reason': "High fraud risk detected.",
                    'parameters': {}
                }

        return decision

    def update_weights(self, feedback):
        """
        Update weights based on feedback (Learning).
        feedback: {'action': str, 'success': bool, 'cost': float}
        """
        action = feedback.get('action')
        success = feedback.get('success')
        
        if action in self.weights:
            if success:
                self.weights[action] = min(self.weights[action] + 0.05, 1.0)
            else:
                self.weights[action] = max(self.weights[action] - 0.05, 0.1)
