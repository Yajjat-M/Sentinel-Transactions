class ReasoningEngine:
    def __init__(self):
        self.baseline_failure_rate = 0.10 # 10% failure is normal-ish
        self.high_latency_threshold = 1000 # ms

    def reason(self, metrics, fraud_prob=0.0):
        """
        Analyze metrics and generate hypotheses.
        """
        hypotheses = []

        # Check Bank Failure Spikes
        bank_rates = metrics.get('bank_failure_rates', {})
        for bank, rate in bank_rates.items():
            if rate > self.baseline_failure_rate * 2: # Significant spike
                confidence = min((rate - self.baseline_failure_rate) / self.baseline_failure_rate, 1.0)
                hypotheses.append({
                    'type': 'issuer_downtime',
                    'target': bank,
                    'confidence': confidence,
                    'reasoning': f"Failure rate for {bank} is {rate:.2f}, significantly above baseline.",
                    'impact': 'high'
                })

        # Check Latency
        avg_latency = metrics.get('global_avg_latency', 0)
        if avg_latency > self.high_latency_threshold:
            hypotheses.append({
                'type': 'network_congestion',
                'target': 'global',
                'confidence': 0.8,
                'reasoning': f"Average latency {avg_latency:.2f}ms is high.",
                'impact': 'medium'
            })

        # Check Fraud
        if fraud_prob > 0.7:
             hypotheses.append({
                'type': 'fraud_attack',
                'target': 'current_transaction',
                'confidence': fraud_prob,
                'reasoning': f"Model predicted high fraud probability: {fraud_prob:.2f}",
                'impact': 'high'
            })

        if not hypotheses:
             hypotheses.append({
                'type': 'normal_operation',
                'target': 'system',
                'confidence': 1.0,
                'reasoning': "Metrics within normal bounds.",
                'impact': 'none'
            })

        return hypotheses
