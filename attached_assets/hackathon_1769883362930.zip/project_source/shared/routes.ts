import { z } from 'zod';
import { transactions, incidents, agentLogs, metrics } from './schema';

export const errorSchemas = {
  internal: z.object({ message: z.string() }),
  notFound: z.object({ message: z.string() }),
  validation: z.object({ message: z.string() })
};

export const api = {
  dashboard: {
    stats: {
      method: 'GET' as const,
      path: '/api/dashboard/stats',
      responses: {
        200: z.object({
          totalVolume: z.number(),
          failureRate: z.number(),
          fraudRate: z.number(),
          activeIncidents: z.number(),
          topRiskyBanks: z.array(z.string())
        })
      }
    },
    recentTransactions: {
      method: 'GET' as const,
      path: '/api/dashboard/transactions',
      responses: {
        200: z.array(z.custom<typeof transactions.$inferSelect>())
      }
    }
  },
  incidents: {
    list: {
      method: 'GET' as const,
      path: '/api/incidents',
      responses: {
        200: z.array(z.custom<typeof incidents.$inferSelect>())
      }
    },
    create: {
      method: 'POST' as const,
      path: '/api/incidents',
      input: z.object({
        type: z.string(),
        severity: z.string(),
        description: z.string(),
        affectedBank: z.string().optional(),
        evidence: z.any().optional(),
        linkedTransactionIds: z.array(z.string()).optional()
      }),
      responses: {
        201: z.custom<typeof incidents.$inferSelect>(),
        400: errorSchemas.validation
      }
    }
  },
  transactions: {
    investigate: {
      method: 'POST' as const,
      path: '/api/transactions/:id/investigate',
      responses: {
        200: z.custom<typeof transactions.$inferSelect>(),
        404: errorSchemas.notFound
      }
    }
  },
  agent: {
    logs: {
      method: 'GET' as const,
      path: '/api/agent/logs',
      responses: {
        200: z.array(z.custom<typeof agentLogs.$inferSelect>())
      }
    }
  },
  metrics: {
    history: {
      method: 'GET' as const,
      path: '/api/metrics/history',
      input: z.object({
        metric: z.string().optional(),
        hours: z.coerce.number().optional().default(1)
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof metrics.$inferSelect>())
      }
    }
  },
  simulation: {
    status: {
      method: 'GET' as const,
      path: '/api/simulation/status',
      responses: {
        200: z.object({
          isRunning: z.boolean(),
          processedCount: z.number(),
          speed: z.number() // transactions per second
        })
      }
    },
    control: {
      method: 'POST' as const,
      path: '/api/simulation/control',
      input: z.object({
        action: z.enum(['start', 'stop', 'reset', 'seed']),
        speedMultiplier: z.number().optional()
      }),
      responses: {
        200: z.object({
          success: z.boolean(),
          message: z.string()
        })
      }
    }
  }
};

// WebSocket Event Types
export const WS_EVENTS = {
  TRANSACTION: 'transaction',
  INCIDENT: 'incident',
  AGENT_LOG: 'agent_log',
  STATS_UPDATE: 'stats_update'
} as const;

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
