import { pgTable, text, serial, integer, boolean, timestamp, jsonb, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export * from "./models/chat";

// === TRANSACTIONS ===
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  transactionId: text("transaction_id").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  amount: doublePrecision("amount").notNull(),
  currency: text("currency").default("INR").notNull(),
  status: text("status").notNull(), // success, failed, halted
  bank: text("bank").notNull(),
  paymentMethod: text("payment_method").notNull(), // upi, netbanking, etc.
  merchantCategory: text("merchant_category"),
  
  // Risk & Fraud
  fraudProbability: doublePrecision("fraud_probability").default(0),
  riskScore: doublePrecision("risk_score").default(0),
  isFlagged: boolean("is_flagged").default(false),
  investigationStatus: text("investigation_status").default("none"), // none, under_investigation, resolved
  failureReason: text("failure_reason"),
  
  // Metadata for simulation
  region: text("region"),
  deviceType: text("device_type"),
  errorCode: text("error_code"),
});

// === INCIDENTS (Retry storms, Bank failures) ===
export const incidents = pgTable("incidents", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // retry_storm, bank_downtime, fraud_spike
  severity: text("severity").notNull(), // low, medium, high, critical
  status: text("status").notNull(), // active, mitigated, resolved
  description: text("description").notNull(),
  affectedBank: text("affected_bank"),
  detectedAt: timestamp("detected_at").defaultNow().notNull(),
  resolvedAt: timestamp("resolved_at"),
  evidence: jsonb("evidence"), // JSON details about why this incident was flagged
  linkedTransactionIds: text("linked_transaction_ids").array(), // Array of transaction IDs
});

// === AGENT LOGS (Observe -> Reason -> Decide -> Act) ===
export const agentLogs = pgTable("agent_logs", {
  id: serial("id").primaryKey(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  module: text("module").notNull(), // observe, reason, decide, act, learn
  level: text("level").notNull(), // info, warning, error
  message: text("message").notNull(),
  details: jsonb("details"), // Structured data for the dashboard
});

// === METRICS (Aggregated stats) ===
export const metrics = pgTable("metrics", {
  id: serial("id").primaryKey(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  name: text("name").notNull(), // failure_rate, transaction_volume, fraud_rate
  value: doublePrecision("value").notNull(),
  tags: jsonb("tags"), // e.g., { bank: "HDFC" }
});

// === SCHEMAS ===
export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true });
export const insertIncidentSchema = createInsertSchema(incidents).omit({ id: true });
export const insertAgentLogSchema = createInsertSchema(agentLogs).omit({ id: true });

// === TYPES ===
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type Incident = typeof incidents.$inferSelect;
export type InsertIncident = z.infer<typeof insertIncidentSchema>;

export type AgentLog = typeof agentLogs.$inferSelect;
export type InsertAgentLog = z.infer<typeof insertAgentLogSchema>;

export type Metric = typeof metrics.$inferSelect;

// === API TYPES ===
export type SimulationStatus = {
  isRunning: boolean;
  totalTransactions: number;
  activeIncidents: number;
  processedCount: number;
};

export type DashboardStats = {
  totalVolume: number;
  failureRate: number;
  fraudRate: number;
  activeIncidents: number;
  topRiskyBanks: string[];
};
