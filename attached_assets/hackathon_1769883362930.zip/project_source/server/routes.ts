import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { simulation } from "./simulation";
import { api } from "@shared/routes";
import { z } from "zod";
import { registerChatRoutes } from "./replit_integrations/chat/routes";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Register AI Chat Routes (for the "Agent Live Feed" if we want to query it, 
  // or if the user wants to chat with the agent)
  registerChatRoutes(app);

  // === DASHBOARD STATS ===
  app.get(api.dashboard.stats.path, async (req, res) => {
    const stats = await storage.getTransactionStats(60); // Last 60 mins
    const activeIncidents = await storage.getActiveIncidents();
    
    // Calculate simple stats
    const totalVolume = stats.total;
    const failureRate = stats.total > 0 ? (stats.failed / stats.total) * 100 : 0;
    const fraudRate = stats.total > 0 ? (stats.fraud / stats.total) * 100 : 0;
    
    res.json({
      totalVolume,
      failureRate: Number(failureRate.toFixed(2)),
      fraudRate: Number(fraudRate.toFixed(2)),
      activeIncidents: activeIncidents.length,
      topRiskyBanks: ["SBI", "HDFC"] // Mock/Placeholder for now
    });
  });

  app.get(api.dashboard.recentTransactions.path, async (req, res) => {
    const txs = await storage.getRecentTransactions(20);
    res.json(txs);
  });

  // === INCIDENTS ===
  app.get(api.incidents.list.path, async (req, res) => {
    const incidents = await storage.getActiveIncidents();
    res.json(incidents);
  });

  app.post(api.incidents.create.path, async (req, res) => {
    try {
      const input = api.incidents.create.input.parse(req.body);
      const incident = await storage.createIncident({
        ...input,
        status: 'active',
        detectedAt: new Date()
      });
      res.status(201).json(incident);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // === TRANSACTIONS ===
  app.post(api.transactions.investigate.path, async (req, res) => {
    const txId = parseInt(req.params.id);
    const tx = await storage.getTransaction(txId);
    if (!tx) return res.status(404).json({ message: "Transaction not found" });
    
    const updated = await storage.updateTransaction(txId, { investigationStatus: 'under_investigation' });
    res.json(updated);
  });

  // === AGENT LOGS ===
  app.get(api.agent.logs.path, async (req, res) => {
    const logs = await storage.getRecentLogs(50);
    res.json(logs);
  });

  // === METRICS ===
  app.get(api.metrics.history.path, async (req, res) => {
    // Mock history data if DB is empty
    const metrics = await storage.getMetrics("failure_rate", 20);
    res.json(metrics);
  });

  // === SIMULATION CONTROL ===
  app.get(api.simulation.status.path, (req, res) => {
    res.json(simulation.getStatus());
  });

  app.post(api.simulation.control.path, async (req, res) => {
    try {
      const { action, speedMultiplier } = api.simulation.control.input.parse(req.body);
      
      switch (action) {
        case 'start':
          simulation.start(speedMultiplier || 1);
          break;
        case 'stop':
          simulation.stop();
          break;
        case 'reset':
          simulation.reset();
          break;
        case 'seed':
          // Seed some initial data
          await storage.createIncident({
            type: "retry_storm",
            severity: "medium",
            status: "resolved",
            description: "Historical: Payment gateway timeout detected.",
            detectedAt: new Date(Date.now() - 86400000), // 1 day ago
            resolvedAt: new Date(Date.now() - 86300000)
          });
          break;
      }
      
      res.json({ success: true, message: `Simulation ${action}ed` });
    } catch (err) {
       if (err instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid input" });
        return;
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}
