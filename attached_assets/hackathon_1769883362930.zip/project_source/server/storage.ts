import { db } from "./db";
import { 
  transactions, incidents, agentLogs, metrics,
  type InsertTransaction, type InsertIncident, type InsertAgentLog,
  type Transaction, type Incident, type AgentLog, type Metric
} from "@shared/schema";
import { desc, eq, sql } from "drizzle-orm";
import { chatStorage } from "./replit_integrations/chat/storage";

export interface IStorage {
  // Transactions
  createTransaction(tx: InsertTransaction): Promise<Transaction>;
  getRecentTransactions(limit?: number): Promise<Transaction[]>;
  getTransaction(id: number): Promise<Transaction | undefined>;
  updateTransaction(id: number, updates: Partial<Transaction>): Promise<Transaction>;
  getTransactionStats(windowMinutes?: number): Promise<{
    total: number;
    failed: number;
    fraud: number;
  }>;
  
  // Incidents
  createIncident(incident: InsertIncident): Promise<Incident>;
  updateIncidentStatus(id: number, status: string, resolvedAt?: Date): Promise<Incident>;
  getActiveIncidents(): Promise<Incident[]>;
  
  // Agent Logs
  createAgentLog(log: InsertAgentLog): Promise<AgentLog>;
  getRecentLogs(limit?: number): Promise<AgentLog[]>;
  
  // Metrics
  createMetric(name: string, value: number, tags?: any): Promise<Metric>;
  getMetrics(name: string, limit?: number): Promise<Metric[]>;

  // Chat (inherited from integration)
  getConversation: typeof chatStorage.getConversation;
  getAllConversations: typeof chatStorage.getAllConversations;
  createConversation: typeof chatStorage.createConversation;
  deleteConversation: typeof chatStorage.deleteConversation;
  getMessagesByConversation: typeof chatStorage.getMessagesByConversation;
  createMessage: typeof chatStorage.createMessage;
}

export class DatabaseStorage implements IStorage {
  // Chat methods delegation
  getConversation = chatStorage.getConversation;
  getAllConversations = chatStorage.getAllConversations;
  createConversation = chatStorage.createConversation;
  deleteConversation = chatStorage.deleteConversation;
  getMessagesByConversation = chatStorage.getMessagesByConversation;
  createMessage = chatStorage.createMessage;

  async createTransaction(tx: InsertTransaction): Promise<Transaction> {
    const [newTx] = await db.insert(transactions).values(tx).returning();
    return newTx;
  }

  async getRecentTransactions(limit = 100): Promise<Transaction[]> {
    return db.select()
      .from(transactions)
      .orderBy(desc(transactions.timestamp))
      .limit(limit);
  }

  async getTransaction(id: number): Promise<Transaction | undefined> {
    const [tx] = await db.select().from(transactions).where(eq(transactions.id, id));
    return tx;
  }

  async updateTransaction(id: number, updates: Partial<Transaction>): Promise<Transaction> {
    const [updated] = await db.update(transactions)
      .set(updates)
      .where(eq(transactions.id, id))
      .returning();
    return updated;
  }

  async getTransactionStats(windowMinutes = 5): Promise<{ total: number; failed: number; fraud: number }> {
    const timeThreshold = new Date(Date.now() - windowMinutes * 60000);
    
    // This is a simplified implementation. 
    // For production, use count() with filters in SQL for efficiency.
    const recent = await db.select()
      .from(transactions)
      .where(sql`${transactions.timestamp} > ${timeThreshold}`);
      
    const total = recent.length;
    const failed = recent.filter(t => t.status === 'failed').length;
    const fraud = recent.filter(t => (t.fraudProbability || 0) > 0.8).length;
    
    return { total, failed, fraud };
  }

  async createIncident(incident: InsertIncident): Promise<Incident> {
    const [newIncident] = await db.insert(incidents).values(incident).returning();
    return newIncident;
  }

  async updateIncidentStatus(id: number, status: string, resolvedAt?: Date): Promise<Incident> {
    const [updated] = await db.update(incidents)
      .set({ status, resolvedAt })
      .where(eq(incidents.id, id))
      .returning();
    return updated;
  }

  async getActiveIncidents(): Promise<Incident[]> {
    return db.select()
      .from(incidents)
      .where(eq(incidents.status, 'active'))
      .orderBy(desc(incidents.detectedAt));
  }

  async createAgentLog(log: InsertAgentLog): Promise<AgentLog> {
    const [newLog] = await db.insert(agentLogs).values(log).returning();
    return newLog;
  }

  async getRecentLogs(limit = 50): Promise<AgentLog[]> {
    return db.select()
      .from(agentLogs)
      .orderBy(desc(agentLogs.timestamp))
      .limit(limit);
  }

  async createMetric(name: string, value: number, tags: any = {}): Promise<Metric> {
    const [metric] = await db.insert(metrics).values({
      name,
      value,
      tags
    }).returning();
    return metric;
  }

  async getMetrics(name: string, limit = 100): Promise<Metric[]> {
    return db.select()
      .from(metrics)
      .where(eq(metrics.name, name))
      .orderBy(desc(metrics.timestamp))
      .limit(limit);
  }
}

export const storage = new DatabaseStorage();
