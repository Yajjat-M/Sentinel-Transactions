import { storage } from "./storage";
import { openai } from "./replit_integrations/image/client"; // Reusing the client from image module which exports it
import { InsertTransaction, InsertIncident, InsertAgentLog } from "@shared/schema";

export class SimulationEngine {
  private isRunning = false;
  private intervalId: NodeJS.Timeout | null = null;
  private speedMultiplier = 1;
  private processedCount = 0;
  
  // Simulation State
  private banks = ["HDFC", "SBI", "ICICI", "Axis", "Kotak"];
  private failureRates: Record<string, number> = {
    "HDFC": 0.05, "SBI": 0.08, "ICICI": 0.02, "Axis": 0.03, "Kotak": 0.04
  };
  private activeIncidents: Set<string> = new Set(); // bank names

  start(speed = 1) {
    if (this.isRunning) return;
    this.isRunning = true;
    this.speedMultiplier = speed;
    this.intervalId = setInterval(() => this.tick(), 1000 / this.speedMultiplier);
    this.logAgent("info", "Simulation started", "system");
  }

  stop() {
    this.isRunning = false;
    if (this.intervalId) clearInterval(this.intervalId);
    this.intervalId = null;
    this.logAgent("info", "Simulation stopped", "system");
  }

  reset() {
    this.stop();
    this.processedCount = 0;
    this.activeIncidents.clear();
    // In a real app we might wipe DB, but here we just reset counters
    this.logAgent("info", "Simulation reset", "system");
  }

  getStatus() {
    return {
      isRunning: this.isRunning,
      processedCount: this.processedCount,
      activeIncidents: this.activeIncidents.size,
      speed: this.speedMultiplier
    };
  }

  private async tick() {
    try {
      // 1. Generate Transactions
      const txCount = Math.floor(Math.random() * 5) + 1; // 1-5 tx per tick
      for (let i = 0; i < txCount; i++) {
        await this.generateTransaction();
      }
      
      // 2. Observe & Reason (Every 5 ticks or so to avoid spamming OpenAI)
      if (this.processedCount % 5 === 0) {
        await this.runAgentLoop();
      }

      this.processedCount += txCount;
    } catch (err) {
      console.error("Simulation tick error:", err);
    }
  }

  private async generateTransaction() {
    const bank = this.banks[Math.floor(Math.random() * this.banks.length)];
    const isIncidentActive = this.activeIncidents.has(bank);
    
    // Higher failure rate if incident active
    const failProb = isIncidentActive ? 0.8 : this.failureRates[bank];
    const isFailed = Math.random() < failProb;
    
    const amount = Math.floor(Math.random() * 10000) + 100;
    const fraudProb = Math.random(); // Simple random for now
    
    const tx: InsertTransaction = {
      transactionId: `TXN-${Date.now()}-${Math.floor(Math.random()*1000)}`,
      amount,
      currency: "INR",
      bank,
      status: isFailed ? "failed" : "success",
      paymentMethod: "UPI",
      fraudProbability: fraudProb,
      riskScore: fraudProb * 100,
      timestamp: new Date(),
      isFlagged: fraudProb > 0.9,
      failureReason: isFailed ? (isIncidentActive ? "Active Bank Incident" : "Timeout") : null,
      investigationStatus: "none"
    };

    await storage.createTransaction(tx);
  }

  private async runAgentLoop() {
    // === OBSERVE ===
    const stats = await storage.getTransactionStats(1); // last 1 min
    const failureRate = stats.total > 0 ? stats.failed / stats.total : 0;
    
    await this.logAgent("info", `Observed failure rate: ${(failureRate * 100).toFixed(1)}%`, "observe", { stats });

    // === REASON ===
    if (failureRate > 0.3) {
      await this.logAgent("warning", "High failure rate detected. Analyzing patterns...", "reason");
      
      // Use OpenAI to "analyze" (simulate reasoning)
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-5.1",
          messages: [{
            role: "system",
            content: "You are a Fintech AI Agent. Analyze the current high failure rate. Output a brief hypothesis."
          }, {
            role: "user",
            content: `Failure Rate: ${(failureRate * 100).toFixed(1)}%. Total Tx: ${stats.total}. Failed: ${stats.failed}.`
          }],
          max_completion_tokens: 100
        });
        
        const reasoning = response.choices[0]?.message?.content || "Pattern analysis inconclusive.";
        await this.logAgent("warning", reasoning, "reason");
        
        // === DECIDE ===
        await this.logAgent("warning", "Escalating to Incident status due to sustained failures.", "decide");
        
        // === ACT ===
        // Find the worst bank
        const bank = "SBI"; // Simplified: assume SBI is the culprit for simulation
        if (!this.activeIncidents.has(bank)) {
            this.activeIncidents.add(bank);
            await storage.createIncident({
                type: "bank_downtime",
                severity: "high",
                status: "active",
                description: `High failure rate detected on ${bank}. Agent initiated suppression.`,
                affectedBank: bank,
                detectedAt: new Date(),
                evidence: { failureRate, reasoning },
                linkedTransactionIds: []
            });
            await this.logAgent("error", `Suppressed ${bank} route to prevent further failures.`, "act");
        }
      } catch (err) {
        console.error("AI Reasoning failed:", err);
      }
    } else {
        // Auto-resolve incidents if healthy
        if (this.activeIncidents.size > 0 && failureRate < 0.1) {
            await this.logAgent("info", "Traffic normalized. Re-enabling routes.", "decide");
            this.activeIncidents.clear();
             // Update DB incidents to resolved (not implemented fully in this loop for brevity)
        }
    }
  }

  private async logAgent(level: string, message: string, module: string, details?: any) {
    await storage.createAgentLog({
      level,
      message,
      module,
      details,
      timestamp: new Date()
    });
  }
}

export const simulation = new SimulationEngine();
