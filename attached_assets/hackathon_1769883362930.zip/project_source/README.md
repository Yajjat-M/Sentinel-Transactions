# Agentic AI Payment Operations System

This is a full agentic AI system for Smart Payment Operations, built in Python.

## Features
- **Observe**: Monitors transaction streams for failures, latency, and fraud.
- **Reason**: Generates hypotheses (e.g., "Issuer Downtime", "Network Congestion").
- **Decide**: Takes actions (Reroute, Adjust Retry, Alert) based on confidence and impact.
- **Act**: Simulates actions and logs them.
- **Learn**: Updates decision weights based on action outcomes.
- **Fraud Detection**: Integrated Random Forest model for real-time risk scoring.

## Project Structure
- `agent/`: Core agent modules (Observe, Reason, Decide, Act, Learn).
- `data/`: Data loading and stream simulation.
- `models/`: Fraud detection model.
- `app/`: Streamlit dashboard.
- `main.py`: CLI simulation runner.

## Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Running the System

### CLI Simulation
Run the simulation in the terminal:
```bash
python main.py
```

### Dashboard
Launch the interactive dashboard:
```bash
streamlit run app/dashboard.py
```
