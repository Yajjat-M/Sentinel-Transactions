import zipfile
import os

def zip_directory(folder_path, output_path):
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(folder_path):
            # Exclude hidden directories and specific folders
            dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['__pycache__', 'node_modules', 'dist', 'build']]
            
            for file in files:
                if file == os.path.basename(output_path) or file.startswith('.'):
                    continue
                    
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, folder_path)
                print(f"Adding {arcname}")
                zipf.write(file_path, arcname)

if __name__ == "__main__":
    project_dir = r"C:\Users\Yajjat Malhotra\Desktop\project_source"
    zip_output = r"C:\Users\Yajjat Malhotra\Desktop\project_source\FinAgent_Source.zip"
    
    print(f"Zipping {project_dir} to {zip_output}...")
    try:
        zip_directory(project_dir, zip_output)
        print("Zip created successfully.")
    except Exception as e:
        print(f"Error creating zip: {e}")
