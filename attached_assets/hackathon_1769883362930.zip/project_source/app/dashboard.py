import streamlit as st
import pandas as pd
import sys
import os
import time
import altair as alt
from datetime import datetime

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from data.dataset_loader import DatasetLoader
from data.stream_simulator import StreamSimulator
from models.fraud_model import FraudModel
from agent.observe import PaymentObserver
from agent.reason import ReasoningEngine
from agent.decide import DecisionEngine
from agent.act import ActionExecutor
from agent.learn import LearningModule

# --- CONFIGURATION ---
st.set_page_config(
    page_title="FinAgent.ai",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- CUSTOM CSS (Shadcn/Replit Style) ---
st.markdown("""
<style>
    /* General Theme Overrides */
    .stApp {
        background-color: #09090b; /* Zinc 950 */
        color: #fafafa; /* Zinc 50 */
    }
    
    /* Sidebar */
    section[data-testid="stSidebar"] {
        background-color: #09090b;
        border-right: 1px solid #27272a; /* Zinc 800 */
    }
    
    /* Cards */
    .metric-card {
        background-color: #18181b; /* Zinc 900 */
        border: 1px solid #27272a;
        border-radius: 0.75rem;
        padding: 1.5rem;
        box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
    }
    
    .metric-label {
        color: #a1a1aa; /* Zinc 400 */
        font-size: 0.875rem;
        font-weight: 500;
    }
    
    .metric-value {
        color: #fafafa;
        font-size: 1.5rem;
        font-weight: 700;
        margin-top: 0.25rem;
    }
    
    .metric-trend {
        font-size: 0.75rem;
        margin-top: 0.5rem;
        display: flex;
        align-items: center;
        gap: 0.25rem;
    }
    
    .trend-up { color: #10b981; } /* Emerald 500 */
    .trend-down { color: #ef4444; } /* Red 500 */
    
    /* Headers */
    h1, h2, h3 {
        font-family: 'Inter', sans-serif;
        font-weight: 600;
        letter-spacing: -0.025em;
    }
    
    /* Buttons */
    .stButton button {
        background-color: #fafafa;
        color: #18181b;
        border-radius: 0.5rem;
        font-weight: 500;
        border: none;
        padding: 0.5rem 1rem;
    }
    .stButton button:hover {
        background-color: #e4e4e7; /* Zinc 200 */
    }

    /* Dataframe */
    .stDataFrame {
        border: 1px solid #27272a;
        border-radius: 0.5rem;
    }
</style>
""", unsafe_allow_html=True)

# --- STATE MANAGEMENT ---
if 'initialized' not in st.session_state:
    st.session_state.initialized = False
    st.session_state.data = None
    st.session_state.model = None
    st.session_state.agent_components = {}
    st.session_state.logs = []
    st.session_state.metrics_history = []
    st.session_state.page = "Dashboard"

def init_system():
    with st.spinner("Initializing FinAgent Core..."):
        loader = DatasetLoader()
        df = loader.get_unified_stream()
        
        model = FraudModel()
        model.train(df)
        
        st.session_state.data = df
        st.session_state.model = model
        
        st.session_state.agent_components = {
            'observer': PaymentObserver(window_size=50),
            'reasoner': ReasoningEngine(),
            'decider': DecisionEngine(),
            'actor': ActionExecutor(),
            'learner': LearningModule()
        }
        
        st.session_state.simulator = StreamSimulator(df)
        st.session_state.initialized = True

# --- COMPONENTS ---

def sidebar():
    with st.sidebar:
        st.markdown("""
        <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 2rem; padding: 0 0.5rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fafafa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a10 10 0 1 0 10 10 4 4 0 0 1-5-5 4 4 0 0 1-5-5"/></svg>
            <span style="font-size: 1.25rem; font-weight: 700;">FinAgent<span style="color: #3b82f6;">.ai</span></span>
        </div>
        """, unsafe_allow_html=True)
        
        pages = ["Dashboard", "Transactions", "Incidents", "Agent Logic"]
        selected = st.radio("", pages, label_visibility="collapsed")
        st.session_state.page = selected
        
        st.divider()
        
        # User Profile Stub
        st.markdown("""
        <div style="display: flex; align-items: center; gap: 0.75rem; padding: 0.75rem; background-color: #18181b; border-radius: 0.5rem; margin-top: auto;">
            <div style="width: 2rem; height: 2rem; border-radius: 9999px; background-color: rgba(59, 130, 246, 0.2); display: flex; align-items: center; justify-content: center; color: #3b82f6; font-weight: 700; font-size: 0.75rem;">JD</div>
            <div>
                <div style="font-size: 0.875rem; font-weight: 500;">Jane Doe</div>
                <div style="font-size: 0.75rem; color: #a1a1aa;">Lead Engineer</div>
            </div>
        </div>
        """, unsafe_allow_html=True)

def metric_card(title, value, trend=None, trend_val=None):
    trend_html = ""
    if trend:
        color_class = "trend-up" if trend == "up" else "trend-down"
        arrow = "↑" if trend == "up" else "↓"
        trend_html = f'<div class="metric-trend {color_class}">{arrow} {trend_val}</div>'
    
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">{title}</div>
        <div class="metric-value">{value}</div>
        {trend_html}
    </div>
    """, unsafe_allow_html=True)

def render_dashboard():
    # Top Stats
    c1, c2, c3, c4 = st.columns(4)
    
    metrics = st.session_state.metrics_history[-1] if st.session_state.metrics_history else {}
    success_rate = metrics.get('success_rate', 0)
    latency = metrics.get('latency', 0)
    
    with c1:
        metric_card("Success Rate", f"{success_rate:.1%}", "up" if success_rate > 0.9 else "down", "2.1%")
    with c2:
        metric_card("Avg Latency", f"{latency:.0f} ms", "down" if latency < 200 else "up", "12ms")
    with c3:
        metric_card("Fraud Risk", "Low", "neutral", "Stable")
    with c4:
        metric_card("Active Incidents", "0", "neutral", "None")

    st.markdown("###") # Spacer

    # Main Content
    col_left, col_right = st.columns([2, 1])
    
    with col_left:
        st.subheader("Transaction Volume Real-time")
        if len(st.session_state.metrics_history) > 0:
            df = pd.DataFrame(st.session_state.metrics_history)
            
            chart = alt.Chart(df).mark_area(
                line={'color':'#3b82f6'},
                color=alt.Gradient(
                    gradient='linear',
                    stops=[alt.GradientStop(color='#3b82f6', offset=0),
                           alt.GradientStop(color='rgba(59, 130, 246, 0)', offset=1)],
                    x1=1, x2=1, y1=1, y2=0
                )
            ).encode(
                x=alt.X('time:T', axis=alt.Axis(format='%H:%M:%S', title=None)),
                y=alt.Y('success_rate:Q', scale=alt.Scale(domain=[0.8, 1.0]), title='Success Rate'),
                tooltip=['time', 'success_rate']
            ).properties(height=350).configure_axis(
                gridColor='#27272a',
                domainColor='#27272a',
                labelColor='#a1a1aa'
            ).configure_view(strokeWidth=0)
            
            st.altair_chart(chart, use_container_width=True)
        else:
            st.info("Waiting for simulation data...")

    with col_right:
        st.subheader("Agent Activity Feed")
        with st.container(height=400):
            if st.session_state.logs:
                for log in reversed(st.session_state.logs[-10:]):
                    icon = "🛡️" if log['action'] == 'block_transaction' else "⚡" if log['action'] == 'reroute' else "ℹ️"
                    st.markdown(f"""
                    <div style="padding: 0.75rem; border-bottom: 1px solid #27272a; font-size: 0.875rem;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 0.25rem;">
                            <span style="font-weight: 600; color: #fafafa;">{icon} {log['action'].upper()}</span>
                            <span style="color: #a1a1aa; font-size: 0.75rem;">{log['time'].strftime('%H:%M:%S')}</span>
                        </div>
                        <div style="color: #a1a1aa;">{log['reason']}</div>
                    </div>
                    """, unsafe_allow_html=True)
            else:
                st.markdown("<div style='color: #a1a1aa; text-align: center; padding: 2rem;'>No activity yet</div>", unsafe_allow_html=True)

def render_transactions():
    st.subheader("Recent Transactions")
    if st.session_state.logs:
        df = pd.DataFrame(st.session_state.logs)
        st.dataframe(df, use_container_width=True)
    else:
        st.info("No transactions logged yet.")

def run_simulation_step():
    batch_size = 5
    
    observer = st.session_state.agent_components['observer']
    reasoner = st.session_state.agent_components['reasoner']
    decider = st.session_state.agent_components['decider']
    actor = st.session_state.agent_components['actor']
    learner = st.session_state.agent_components['learner']
    model = st.session_state.model
    
    for txn in st.session_state.simulator.stream(batch_size=batch_size, delay=0):
        # 1. Fraud
        fraud_prob = model.predict_proba(txn)
        txn['fraud_score_predicted'] = fraud_prob
        
        # 2. Observe
        observer.observe(txn)
        metrics = observer.get_metrics()
        
        # 3. Reason
        hypotheses = reasoner.reason(metrics, fraud_prob)
        
        # 4. Decide
        decision = decider.decide(hypotheses)
        
        # 5. Act
        log = actor.execute(decision)
        
        # 6. Learn
        feedback = learner.learn(log, metrics)
        if feedback:
            decider.update_weights(feedback)
        
        # Store logs
        st.session_state.logs.append({
            'time': txn['timestamp'],
            'status': txn['status'],
            'bank': txn.get('issuer_bank'),
            'fraud_prob': fraud_prob,
            'action': decision['action'],
            'reason': decision['reason']
        })
        
        if metrics:
            st.session_state.metrics_history.append({
                'time': txn['timestamp'],
                'success_rate': metrics.get('global_success_rate', 0),
                'latency': metrics.get('global_avg_latency', 0)
            })

# --- MAIN APP ---
sidebar()

if not st.session_state.initialized:
    st.title("Welcome to FinAgent.ai")
    st.markdown("The autonomous AI agent for smart payment operations.")
    if st.button("Initialize System"):
        init_system()
        st.rerun()
else:
    # Header
    col_head_1, col_head_2 = st.columns([3, 1])
    with col_head_1:
        st.title(st.session_state.page)
    with col_head_2:
        # Auto-refresh logic
        if 'auto_run' not in st.session_state:
            st.session_state.auto_run = False
        
        if st.button("⏯️ Start/Stop Simulation", use_container_width=True):
            st.session_state.auto_run = not st.session_state.auto_run
            st.rerun()
            
    if st.session_state.auto_run:
        run_simulation_step()
        time.sleep(1) # Pause for visual effect
        st.rerun()

    # Routing
    if st.session_state.page == "Dashboard":
        render_dashboard()
    elif st.session_state.page == "Transactions":
        render_transactions()
    elif st.session_state.page == "Incidents":
        st.info("Incident Management Module - Coming Soon")
    elif st.session_state.page == "Agent Logic":
        st.subheader("🧠 Agent Reasoning State")
        
        # Split into Reason (Hypotheses) and Decide (Strategy)
        col_reason, col_decide = st.columns(2)
        
        with col_reason:
            st.markdown("### Active Hypotheses")
            st.markdown("The agent's current understanding of potential failure roots.")
            
            # Mock or retrieve real hypotheses state if stored
            # For visualization, we'll pull the latest decision context if available
            if st.session_state.logs:
                latest_log = st.session_state.logs[-1]
                # We need to store hypotheses in logs to show them here, 
                # or just show the reasoning engine's internal weights/priors
                
                # Visualizing Failure Priors from Reasoning Engine
                reasoner = st.session_state.agent_components['reasoner']
                priors = reasoner.failure_priors
                
                priors_df = pd.DataFrame(list(priors.items()), columns=['Failure Type', 'Prior Probability'])
                
                chart_priors = alt.Chart(priors_df).mark_bar().encode(
                    x=alt.X('Prior Probability:Q', scale=alt.Scale(domain=[0, 1])),
                    y=alt.Y('Failure Type:N', sort='-x'),
                    color=alt.Color('Prior Probability:Q', scale=alt.Scale(scheme='blues')),
                    tooltip=['Failure Type', 'Prior Probability']
                ).properties(height=300)
                
                st.altair_chart(chart_priors, use_container_width=True)
            else:
                st.info("Run simulation to generate hypotheses.")

        with col_decide:
            st.markdown("### Decision Strategy")
            st.markdown("Current weightings for action selection based on feedback.")
            
            decider = st.session_state.agent_components['decider']
            weights = decider.action_weights
            
            # Convert nested dict to dataframe for heatmap or bar chart
            # weights structure: {hypothesis: {action: weight}}
            
            weight_data = []
            for hyp, actions in weights.items():
                for act, w in actions.items():
                    weight_data.append({'Hypothesis': hyp, 'Action': act, 'Weight': w})
            
            if weight_data:
                df_weights = pd.DataFrame(weight_data)
                
                chart_weights = alt.Chart(df_weights).mark_rect().encode(
                    x='Action:N',
                    y='Hypothesis:N',
                    color=alt.Color('Weight:Q', scale=alt.Scale(scheme='viridis')),
                    tooltip=['Hypothesis', 'Action', 'Weight']
                ).properties(height=300)
                
                st.altair_chart(chart_weights, use_container_width=True)
            else:
                st.info("No decision weights initialized.")

        # Feedback Loop Visualization
        st.markdown("### 🔄 Learning Feedback Loop")
        if st.session_state.metrics_history:
             st.line_chart(pd.DataFrame(st.session_state.metrics_history).set_index('time')[['success_rate']])
             st.caption("Global Success Rate (Reward Signal)")
