import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import joblib
import os

class FraudModel:
    def __init__(self):
        self.model = RandomForestClassifier(n_estimators=50, max_depth=10, random_state=42)
        self.le_bank = LabelEncoder()
        self.le_method = LabelEncoder()
        self.is_trained = False

    def train(self, df):
        """
        Trains the model on the provided dataframe.
        Expects columns: amount, issuer_bank, retry_count, payment_method (if avail), is_suspicious (target)
        """
        # Filter for training data (rows with known labels)
        # We assume 'is_suspicious' is the target.
        if 'is_suspicious' not in df.columns:
            print("No target column 'is_suspicious' found. Skipping training.")
            return

        # Preprocessing
        data = df.copy()
        
        # Fill NA
        data['amount'] = data['amount'].fillna(0)
        data['retry_count'] = data['retry_count'].fillna(1)
        data['issuer_bank'] = data['issuer_bank'].fillna('UNKNOWN')
        data['payment_method'] = data.get('payment_method', pd.Series(['upi']*len(data))).fillna('upi')

        # Encode categorical
        # Fit encoders
        self.le_bank.fit(pd.concat([data['issuer_bank'], pd.Series(['UNKNOWN'])]))
        self.le_method.fit(pd.concat([data['payment_method'], pd.Series(['upi'])]))

        X = pd.DataFrame()
        X['amount'] = data['amount']
        X['retry_count'] = data['retry_count']
        X['bank_encoded'] = self.le_bank.transform(data['issuer_bank'])
        X['method_encoded'] = self.le_method.transform(data['payment_method'])
        
        y = data['is_suspicious'].astype(int)

        self.model.fit(X, y)
        self.is_trained = True
        print("Fraud Model trained successfully.")

    def predict_proba(self, transaction):
        """
        Predicts fraud probability for a single transaction (dict).
        """
        if not self.is_trained:
            return 0.0 # Default low risk if not trained

        # Prepare input
        bank = transaction.get('issuer_bank', 'UNKNOWN')
        method = transaction.get('payment_method', 'upi')
        
        # Handle unseen labels safely
        if bank not in self.le_bank.classes_:
            bank = 'UNKNOWN'
        if method not in self.le_method.classes_:
            method = 'upi'

        X_new = pd.DataFrame([{
            'amount': transaction.get('amount', 0),
            'retry_count': transaction.get('retry_count', 1),
            'bank_encoded': self.le_bank.transform([bank])[0],
            'method_encoded': self.le_method.transform([method])[0]
        }])

        prob = self.model.predict_proba(X_new)[0][1] # Probability of class 1 (Fraud)
        return prob

if __name__ == "__main__":
    # Test stub
    model = FraudModel()
    # Mock data
    df = pd.DataFrame({
        'amount': [100, 20000, 50],
        'issuer_bank': ['HDFC', 'SBI', 'HDFC'],
        'retry_count': [1, 5, 1],
        'payment_method': ['upi', 'card', 'upi'],
        'is_suspicious': [False, True, False]
    })
    model.train(df)
    print(model.predict_proba({'amount': 20000, 'issuer_bank': 'SBI', 'retry_count': 5, 'payment_method': 'card'}))
