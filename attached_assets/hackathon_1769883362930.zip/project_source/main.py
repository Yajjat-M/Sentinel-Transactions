from data.dataset_loader import DatasetLoader
from data.stream_simulator import StreamSimulator
from models.fraud_model import FraudModel
from agent.observe import PaymentObserver
from agent.reason import ReasoningEngine
from agent.decide import DecisionEngine
from agent.act import ActionExecutor
from agent.learn import LearningModule
import pandas as pd

def main():
    print("Initializing AI Agent System...")
    
    # 1. Load Data
    loader = DatasetLoader()
    try:
        stream_df = loader.get_unified_stream()
        print(f"Data loaded: {len(stream_df)} records.")
    except Exception as e:
        print(f"Error loading data: {e}")
        return

    # 2. Train Models
    print("Training Fraud Model...")
    fraud_model = FraudModel()
    fraud_model.train(stream_df)

    # 3. Initialize Agent Components
    observer = PaymentObserver(window_size=20)
    reasoner = ReasoningEngine()
    decider = DecisionEngine()
    actor = ActionExecutor()
    learner = LearningModule()

    # 4. Start Simulation Loop
    simulator = StreamSimulator(stream_df)
    
    print("Starting Simulation Loop (Processing first 50 transactions)...")
    count = 0
    for txn in simulator.stream(delay=0.01): # Fast simulation
        if count >= 50: break
        
        # --- AGENT LOOP ---
        
        # 1. Fraud Detection
        fraud_prob = fraud_model.predict_proba(txn)
        txn['fraud_score_predicted'] = fraud_prob
        
        # 2. Observe
        observer.observe(txn)
        metrics = observer.get_metrics()
        
        # 3. Reason
        hypotheses = reasoner.reason(metrics, fraud_prob)
        
        # 4. Decide
        decision = decider.decide(hypotheses)
        
        # 5. Act
        log = actor.execute(decision)
        
        # 6. Learn
        feedback = learner.learn(log, metrics)
        if feedback:
            decider.update_weights(feedback)
            
        # Output status
        print(f"Txn {count}: {txn['status']} | Fraud: {fraud_prob:.2f} | Action: {decision['action']}")
        
        count += 1

    print("Simulation Complete.")

if __name__ == "__main__":
    main()
